const firebaseConfig = {

    apiKey: "AIzaSyBq8J8sB-WLU2-F8foug2bXlk3fIYq6Qa4",
    authDomain: "contactform-369f8.firebaseapp.com",
    databaseURL: "https://contactform-369f8-default-rtdb.firebaseio.com",
    projectId: "contactform-369f8",
    storageBucket: "contactform-369f8.appspot.com",
    messagingSenderId: "203332348833",
    appId: "1:203332348833:web:185706bb13dd06d91fb9e0",
    measurementId: "G-WLFVK4WSW4"

};
// initialize firebase

firebase.initializeApp(firebaseConfig);

// reference your database

var contactFormDB = firebase.database().ref("contactForm");

document.getElementById("contactForm").addEventListener("submit", submitForm);

function submitForm(e) {

    e.preventDefault();

    var name = getElementVal("name");

    var emailid = getElementVal("emailid");

    var password = getElementVal("password");

    var number = getElementVal("number");

    console.log(name, emailid, password, number);

    saveMessages(name, emailid, password, number);

    // enable alert

    document.querySelector(".alert").style.display = "block";

    // remove the alert

    setTimeout(() => {

        document.querySelector(".alert").style.display = "none";

    }, 3000);

    // reset the form

    document.getElementById("contactForm").reset();

    return valid;

}

const saveMessages = (name, emailid, password, number) => {

    var newContactForm = contactFormDB.push();

    newContactForm.set({

        name: name,

        emailid: emailid,

        password: password,

        number: number,

    });

};

const getElementVal = (id) => {

    return document.getElementById(id).value;

};